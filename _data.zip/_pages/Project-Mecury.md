---
permalink: /Projects/
title: "Project Mecury"
---

# Introduction and summary
Project Mercury is a single player first person shooter that focuses on advanced movement made for the purpose of demonstrating the team's ability to create a high quality game in Unreal Engine. (expand)

My personal goal for the project was to make use of Unreal Engine's BTrees to create high quality enemies which challenge the player. In order to accomplish my goal I focused primarily on enemy behaviour. The first is a standard robot with a gun. This robot has three variants. One which carries an assualt rifle. The second carries a shotgun and a shield. The third variant carries a sniper and uses teleportation to move between vantage points. The other is a simple, yet effective, explosive enemy which charges the player and then explodes. 


# (Boom Agent Image)

The first enemy I created is the Boom Agent. This was also used as my introduction to learning Unreal. The Boom Agent is fast enemy which is stationary until detecting the player. Once it detects the player the Boom Agent charges them down and detonates the bomb embedded within it. To implement the behaviour I initially created a simple BTree and blackboard to be used by the AI Controller. However, this early version would leave behind a gamebreaking bug only caught later in development. This bug occured when two of these agents exploded next to each other and caused an infinite death loop between the two. I fixed this with a restructure to a more robust and appropriate use of BTrees and blackboards as my knowledge expanded. The final version of the BTree and blackboard are shown below.

# (boom btree image)
# (boom blackboard image)

The BTRee initially consisted of just two selectors and a sequence node. However, I learned that it is better to explicitly use a state based structure on top of the one created by using BTrees in the first place. This allows for more definitive control when making decisions. 

The BTree for the Boom Agent consists of three states. The first is a Passive state. In this state the Boom Agent is waiting for the player to be detected. From this state in can transition into either the Investigating, or the Attacking state. The Investigating state is triggered when the Boom Agent hears the player. The Boom Agent then moves towards the location of the sound stimulus which stored as a vector in the PointOfInterest variable. From here it can transition either to the attacking state or return to its passive state. Finally, is the Attacking state. This state is for when the Boom Agent has visually confirmed the presence of the player. At this point the Boom Agent charges the player until the are within the required distance from the player. Once in range the Boom Agent detonates itself.

# Version 1 of Patrol Agents
The second enemy type I created uses a versatile base which can wield an assualt rifle, a shotgun, or a sniper. These enemies patrol through a set of points waiting until they hear or see the player. This base was designed with the goal creating variant blueprints of the agents with tuned BTree's would be an easy task. The first version of these agents utilized my initial understanding of Unreal Engine. These versions would be replaced later on with the exception of the sniper variant. The reason the sniper variant remains with the old structure is simply because it worked as intended. As such other tasks took priority. The sniper variant's BTree and blackboard are shown below.

# (sniper BTRee)
# (sniper blackboard)

The Sniper Agent's BTree is based off of sequences responding to perception. The task on the far left is a stun task used for when the agent gets stunned. Beyond that it contains three sequences. The idle sequence which preforms a disengage task to set the animation and alert state of the agent. If the agent is not alerted this task fails allowing the sniper to move along its patrol route via teleporting from one vantage point to the next. The sight sequence tells the sniper they are engaged in with the player and to shoot at the player. Finally, the sound detection sequence causes the sniper to shoot at sound the source of the sound as if they were startled. This sequence only occurs if the sniper can not see the player.

# Perception

# Making use of the Environment Query System

# Tasks

# Cut Content

# Conclusion

